// Shared cron authentication guard.
// Usage: const deny = cronGuard(req); if (deny) return deny;
//
// Defends against:
//  1. CRON_SECRET not set — refuse all cron requests (fail closed)
//  2. Missing / malformed / wrong Authorization header
//  3. Timing side-channels — secret comparison is constant-time

import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";

/**
 * Constant-time string compare. Returns false (never throws) on length
 * mismatch or non-string input, so it is safe to call on untrusted headers.
 */
export function safeEqual(a: string | null | undefined, b: string | null | undefined): boolean {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return timingSafeEqual(ab, bb);
}

function authorized(req: Request | NextRequest): { ok: boolean; configured: boolean } {
  const secret = process.env.CRON_SECRET;
  if (!secret) return { ok: false, configured: false };
  const header = req.headers.get("authorization");
  return { ok: safeEqual(header, `Bearer ${secret}`), configured: true };
}

export function cronGuard(req: Request | NextRequest): Response | null {
  const { ok, configured } = authorized(req);
  if (!configured) {
    console.error("[cron-auth] CRON_SECRET is not set — rejecting all cron requests");
    return new Response("Service not configured", { status: 503 });
  }
  if (!ok) return new Response("Unauthorized", { status: 401 });
  return null;
}

// NextResponse variant for routes that use NextResponse
export function cronGuardNext(req: Request | NextRequest): NextResponse | null {
  const { ok, configured } = authorized(req);
  if (!configured) {
    console.error("[cron-auth] CRON_SECRET is not set — rejecting all cron requests");
    return NextResponse.json({ error: "Service not configured" }, { status: 503 });
  }
  if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return null;
}
