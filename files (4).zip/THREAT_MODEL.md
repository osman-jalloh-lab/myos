# Hermes OS — Threat Model (lightweight)

A short, living document. The goal is not formality; it is to write down what
we are protecting, from whom, and where the known soft spots are.

## What we protect

- **Google OAuth tokens** (Gmail read, Calendar read/write, Gmail compose). The
  highest-value asset. Compromise = read of the operator's mail and calendar.
- **Telegram channel** to the operator (commands in, notifications out).
- **Personal data**: finance entries, job applications, memory, chat history.
- **Model + service API keys** (Groq, OpenAI, Anthropic, GitHub PAT, E2B, etc.).

## Trust boundaries

| Entry point | Who can call it | Control |
|---|---|---|
| Browser UI / `/api/*` user routes | Authenticated owner | NextAuth session |
| `/api/cron/*` | Vercel Cron | `CRON_SECRET`, constant-time |
| `/api/telegram/webhook` | Telegram | secret token + owner chat-ID check |
| `/api/hermes-bridge` | Claude Code MCP | `HERMES_BRIDGE_KEY`, constant-time |
| `/api/hermes/execute` | Owner session or MCP gateway | session OR `PARAWI_MCP_API_KEY` |
| `/api/accounts/callback` | Google redirect | HMAC-signed, expiring `state` |

## Primary risks and current mitigations

1. **Token theft at rest** — AES-256-GCM, version-prefixed, authenticated; key
   in `TOKEN_ENCRYPTION_KEY`. A tampered `v1:` token throws rather than being
   silently trusted.
2. **Unauthorized API access** — every route gated; secret compares are
   constant-time; cron fails closed when `CRON_SECRET` is unset.
3. **Prompt-injection into the execution layer** — inbound text (Telegram,
   chat) can influence the planner, but the planner only maps to a fixed tool
   catalog, destructive tools are hard-blocked, and code execution is disabled
   by default. Worst case from injection is a non-destructive tool call.
4. **Arbitrary code execution (E2B / Prometheus)** — sandboxed, 30s timeout,
   OFF unless `HERMES_CODE_EXECUTION_ENABLED=true`; build repos default private.
5. **OAuth CSRF / replay** — link `state` is HMAC-signed and now expires after
   10 minutes.

## Known limitations / accepted risk

- **No true one-time nonce store on OAuth `state`.** Replay is bounded by the
  10-minute expiry and the fact that a replay only re-links the same Google
  account to the same owner. Add a server-side nonce store before going
  multi-user.
- **No pre-execution approval queue for code tools.** Approval for
  `external_write` tools currently uses a "self-queue" pattern that executes the
  tool first; this is wrong for tools where execution itself is the risky act.
  For now those tools are gated entirely by `HERMES_CODE_EXECUTION_ENABLED`.
  Future: a real "queue then run on approval" path.
- **Rate limiting is per-instance in-memory.** Fine for a single operator; move
  to Vercel KV / Upstash for distributed enforcement.
- **No Content-Security-Policy yet.** Baseline headers are set; add a CSP in
  Report-Only mode first, then enforce.

## Review triggers

Revisit this document when: adding a new external-write tool, enabling code
execution, adding a second user, or wiring a new inbound entry point.
