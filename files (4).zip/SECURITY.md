# Security Policy

Hermes OS is a single-operator personal system. It still handles sensitive data
(OAuth tokens for Gmail and Calendar, Telegram messages, finance entries), so it
is treated as a real security boundary.

## Reporting

This is a private project. If you find an issue, open a private security
advisory on the repository or contact the owner directly. Do not file public
issues for anything that could expose tokens or personal data.

## Secrets

- All secrets live in environment variables (see `.env.example`). Never commit
  real values. `.env*` is gitignored.
- OAuth access and refresh tokens are encrypted at rest with AES-256-GCM
  (`src/lib/encrypt.ts`, key `TOKEN_ENCRYPTION_KEY`). Ciphertexts are version
  prefixed (`v1:`) and authenticated — a tampered token fails closed.
- If a secret is ever committed, rotate it immediately (it is in git history
  even after deletion) and purge history if needed.

## Authentication and authorization

- All `/api` routes are gated: user routes by NextAuth session, cron routes by
  `CRON_SECRET`, the bridge by `HERMES_BRIDGE_KEY`, the Telegram webhook by its
  secret token plus an owner chat-ID check, and the MCP execute path by
  `PARAWI_MCP_API_KEY`.
- All shared-secret comparisons are constant-time (`safeEqual` in
  `src/lib/cron-auth.ts`).

## Execution layer

- Destructive tools (send email, delete thread, delete file, apply to job,
  execute payment) are permanently blocked in the executor.
- Code-execution tools (`internal.code.*`) are OFF unless
  `HERMES_CODE_EXECUTION_ENABLED="true"`. Code runs only in the E2B sandbox and
  Prometheus build repos default to private.

## Dependencies

- `npm audit` runs in CI (advisory). Dependabot opens weekly update PRs.
