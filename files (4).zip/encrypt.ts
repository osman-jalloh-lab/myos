import { createCipheriv, createDecipheriv, randomBytes } from "crypto";

// AES-256-GCM token encryption.
// TOKEN_ENCRYPTION_KEY must be 64 hex chars (32 bytes). Required in ALL envs.
// Generate: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
//
// Format: new ciphertexts are prefixed "v1:" so decrypt can tell an
// authenticated ciphertext apart from a legacy plaintext token. A "v1:" value
// that fails the GCM auth tag is TAMPERING and throws — it is never silently
// returned. Unprefixed values are handled for backward compatibility:
//   1. try to decrypt as the original (pre-prefix) iv|tag|ct base64 layout
//   2. if that fails, treat as a legacy plaintext token (one-time migration)

const VERSION_PREFIX = "v1:";
const KEY_HEX = process.env.TOKEN_ENCRYPTION_KEY ?? "";

function requireKey(): Buffer {
  if (!KEY_HEX) {
    throw new Error(
      "TOKEN_ENCRYPTION_KEY is not set. " +
      "Generate one: node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\" " +
      "and add it to .env.local and Vercel env vars."
    );
  }
  if (KEY_HEX.length !== 64) {
    throw new Error(
      `TOKEN_ENCRYPTION_KEY must be 64 hex characters (32 bytes). Got ${KEY_HEX.length} characters.`
    );
  }
  return Buffer.from(KEY_HEX, "hex");
}

// Low-level: decrypt an iv(12)|tag(16)|ciphertext base64 blob. Throws on failure.
function decryptBlob(b64: string): string {
  const buf = Buffer.from(b64, "base64");
  if (buf.length < 29) throw new Error("ciphertext too short");
  const key = requireKey();
  const iv = buf.subarray(0, 12);
  const tag = buf.subarray(12, 28);
  const data = buf.subarray(28);
  const decipher = createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);
  return decipher.update(data).toString("utf8") + decipher.final("utf8");
}

export function encrypt(plaintext: string): string {
  const key = requireKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  // layout: iv(12) | tag(16) | ciphertext — base64, version-prefixed
  return VERSION_PREFIX + Buffer.concat([iv, tag, encrypted]).toString("base64");
}

export function decrypt(ciphertext: string): string {
  // v1: authenticated ciphertext — must decrypt cleanly or it is tampered.
  if (ciphertext.startsWith(VERSION_PREFIX)) {
    return decryptBlob(ciphertext.slice(VERSION_PREFIX.length));
  }

  // Backward compat: original unprefixed iv|tag|ct base64 layout.
  try {
    return decryptBlob(ciphertext);
  } catch {
    // Not a decryptable ciphertext — treat as a legacy plaintext token.
    // This path only exists for one-time migration; values re-encrypt (and
    // pick up the v1: prefix) on the next token refresh / login.
    console.warn("[encrypt] Found legacy plaintext token — will re-encrypt on next refresh");
    return ciphertext;
  }
}
